import React from "react";
import classes from "./footer.module.css";
import dtec from "../../assets/dtec.jpg";
import Munchen from "../../assets/munchen.jpg";
import Media from "../../assets/bayern.jpg";
import reader from "../../assets/reader.jpg";
import twitter from "../../assets/twitterA.png";
import facebook from "../../assets/facebook.png";
import instagram from "../../assets/instagram.png";

const Footer = () => {
  return (
    <footer className={classes.footer}>
      <div className={classes.container}>
        <div className={classes.partners}>
          <h1>Partners</h1>
          <img src={dtec} alt="dtec" className={classes.partnerLogo} />
          <img src={Munchen} alt="Munchen" className={classes.partnerLogo} />
          <img
            src={Media}
            alt="Media Lab Bayern"
            className={classes.partnerLogo}
          />
        </div>
        <div className={classes.about}>
          <h1>About</h1>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignContent: "center",
              margin:'0 auto'
            }}
          >
            <ul>
              <li>Our Projects</li>
              <li>Careers</li>
            </ul>
          </div>
        </div>
        <div className={classes.support}>
          <h1>Support</h1>
          <div>
            <ul>
              <li>Support Request</li>
              <li>Contact</li>
            </ul>
          </div>
        </div>
        <div className={classes.partner}>
          <h1>Partnership</h1>
          <div>
            <ul>
              <li>Websites</li>
              <li>Social Media</li>
              <li>Branding</li>
            </ul>
          </div>
        </div>
        <div className={classes.whatsapp}>
          <h3>Join our Whatsapp</h3>
          <img src={reader} className={classes.reader} alt="Scan the logo" />
          <div className={classes.icons}>
            <img src={facebook} alt="facebook" className={classes.logo} />
            <img src={instagram} alt="instagram" className={classes.logo} />
            <img src={twitter} alt="twitter" className={classes.logo} />
          </div>
        </div>
      </div>
      <h2
        style={{
          textAlign: "right",
        }}
        className={classes.footer1}
      >
        Developed By TOMO Team
      </h2>
    </footer>
  );
};

export default Footer;
